import 'package:test/test.dart'; // Import the test package

import './Calculator.dart'; // Import your Calculator class

void main() {
  group('Calculator', () {
    // Use `group` from the test package
    final calculator = Calculator();

    test('adds two numbers', () {
      expect(calculator.add(1, 1),
          equals(2)); // Use `expect` and `equals` from the test package
    });

    test('subtracts two numbers', () {
      expect(calculator.subtract(5, 2), equals(3));
    });

    test('multiplies two numbers', () {
      expect(calculator.multiply(3, 5), equals(15));
    });

    test('divides two numbers', () {
      expect(calculator.divide(10, 2), equals(5));
    });

    test('throws an ArgumentError when dividing by zero', () {
      expect(
          () => calculator.divide(5, 0),
          throwsA(const TypeMatcher<
              ArgumentError>())); // Use throwsA for error handling
    });
  });
}
