package org.example;

public class Calculator {

        private int first;
        private int second;

        public Calculator() {
        }





        public int Add (int x , int y) {
            int sum = x + y;
            return sum;


        }

        public int Subtract (int x , int y){
            int subtract = x-y;
            return subtract;
        }

        public int Multiply (int x , int y){
            int Multiply = x*y;
            return Multiply;
        }

        public int Division (int x , int y){
            int Division = x/y;
            return Division;
        }


    }


