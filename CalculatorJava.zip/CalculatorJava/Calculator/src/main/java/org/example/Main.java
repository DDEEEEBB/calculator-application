package org.example;

public class Main {
    public static void main(String[] args) {

        Calculator calculator = new Calculator();

        calculator.Add(2, 2);
        calculator.Subtract(2 , 2);
        calculator.Multiply(2,2);
        calculator.Division(2 , 2);
    }
}